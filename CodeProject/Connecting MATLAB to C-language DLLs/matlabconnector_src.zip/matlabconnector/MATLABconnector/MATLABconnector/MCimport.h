extern "C" {

#ifndef _SHELL_H_
#define _SHELL_H_


#ifndef EXPORT
#define EXPORT
#endif

EXPORT void fnMATLABconnector(int key);


#endif //_SHELL_H_

}