__declspec(dllexport) void fnMATLABconnector(int key);
