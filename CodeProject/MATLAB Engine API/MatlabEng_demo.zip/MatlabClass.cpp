// MatlabClass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MatlabEng.h"

#define message(x) printf(x"\n\n")

int main(int argc, char* argv[])
{
	CMatlabEng matlab;
	
	//open new matlab session
	message("Starting MATLAB");
	matlab.Open(NULL);

	message("Hiding MATLAB");
	matlab.SetVisible(FALSE);
	message("Press any key to continue");
	getch();

	message("Showing MATLAB");
	matlab.SetVisible(TRUE);
	message("Press any key to continue");
	getch();
	
	mxArray *T = NULL;
	double time[10] = { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0 };

	//create matrix
	T = mxCreateDoubleMatrix(1, 10, mxREAL);
	memcpy((void *)mxGetPr(T), (void *)time, sizeof(time));
	
	//send matrix T to matlab
	message("Send matrix T to matlab");
	matlab.PutVariable("T", T);

	//Evaluate matlab command
	matlab.EvalString("D = .5.*(-9.8).*T.^2;");

	//Plot results
	message("Plot(T, D)");
	matlab.EvalString("plot(T,D);");	
	matlab.EvalString("title('Position vs. Time for a falling object');");
	matlab.EvalString("xlabel('Time (seconds)');");
	matlab.EvalString("ylabel('Position (meters)');");
	matlab.EvalString("grid;");

	//pause to see results
	message("Press any key to continue");
	getch();
	
	//destroy matrix
	mxDestroyArray(T);
	
	//show MATLAB graphics capabilities
	message("Showing MATLAB graphics capabilities");
	matlab.EvalString("z=peaks(25);");
	matlab.EvalString("surf(z);");
	matlab.EvalString("colormap(jet);");
	matlab.EvalString("knot;");

	//pause
	getch();

	//close session
	matlab.Close();

	return 0;
}

