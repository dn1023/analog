// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: library that encapsulates the COM Matlab interface
using System;
using MATLibrary;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic;

namespace COMMATLib
{
	/// <summary>
	/// MATLAB Interface Class for C# using IDispatch interface
	/// We can't use the TypeLibrary Import mechanism because it seems broken (from VB6 too)	
	/// </summary>
	public class COMMATAccess: MATAccess
	{
		/// <summary>
		/// Creates the connection
		/// </summary>
		public COMMATAccess()
		{
			matObject = Interaction.CreateObject("Matlab.Application","");
		}

		/// <summary>
		/// Evaluates an expression and returns true on completion		
		/// </summary>
		/// <param name="expression">the MATLAB expression</param>
		/// <returns>true on success</returns>
		public bool Evaluate(string expression)
		{
			if(!Active) return false;
			try 
			{
				argsGet[0] = expression;
				return LateBinding.LateGet(matObject,null, "Execute", argsGet, null, null) != null;
			}
			catch(Exception )
			{
				return false;
			}
		}

		/// <summary>
		/// Evaluates an expression and returns a string
		/// </summary>
		/// <param name="expression">the MATLAB expression</param>
		/// <returns>the MATLAB response</returns>
		public string EvaluateAsString(string expression)
		{
			if(!Active) return null;		
			try 
			{
				object rObject = LateBinding.LateGet(matObject,null, "Execute", argsCall, null, null);
				if(rObject == null)
					return null;
				return StringType.FromObject(rObject);
			}
			catch(Exception )
			{
				return null;
			}
		}

		/// <summary>
		/// Say if the MATLAB window is visible
		/// </summary>
		/// <returns></returns>
		public bool IsVisible()
		{
			// TODO
			return true;
		}

		/// <summary>
		/// Fixes the MATLAB windows visibility
		/// </summary>
		/// <param name="b"></param>
		public void SetVisible(bool b)
		{
			if(!Active) return ;
			// TODO
		}
		
		/// <summary>
		/// Gets a matrix variable 
		/// We use a trick: first get the matrix size using 
		///    
		/// </summary>
		/// <param name="name">name of the matrix</param>
		/// <param name="data">the matrix, preallocated or not</param>
		/// <returns></returns>
		public bool GetMatrix(string name, ref double [,] data)
		{
			if(!Active) 
				return false;
			
			// first try directly
			if(GetMatrixNoResize(name, ref data))
				return true;

			int nr, nc;
			if(!GetMatrixSize(name, out nr, out nc))
				return false;
			
			if(data == null || data.GetLength(0) != nr || data.GetLength(1) != nc)
				data = new double[nr,nc];

			return GetMatrixNoResize(name, ref data);
		}

		/// <summary>
		/// Gets the size of the specified Matrix Variable
		/// </summary>
		/// <param name="name"></param>
		/// <param name="nr"></param>
		/// <param name="nc"></param>
		/// <returns></returns>
		public bool GetMatrixSize(string name, out int nr, out int nc)
		{
			nr = nc = 0;
			if(!Evaluate(String.Format("{0} = size({1});", supportVariable, name)))
				return false;
			if(!GetMatrixNoResize(supportVariable, ref MSize))
				return false;
			nr = (int)MSize[0,0];
			nc = (int)MSize[0,1];
			return true;
		}

		/// <summary>
		/// Gets a Matrix Variable and put it into a double array
		/// If the array it's not of the correct size the method fails
		/// </summary>
		/// <param name="name"></param>
		/// <param name="data"></param>
		/// <returns></returns>
		public bool GetMatrixNoResize(string name, ref double[,] data)
		{
			if(data != null)
			{
				try 
				{
					argsCall[0] = name;
					argsCall[1] = workspace;
					argsCall[2] = data;
					argsCall[3] = MEmpty;
					LateBinding.LateCall(matObject, null, "GetFullMatrix", argsCall, null, argsCallBack);
					data = (double[,])argsCall[2];				
					return true;
				}
				catch(Exception )
				{				
				}				
			}
			return false;		
		}		

		/// <summary>
		/// Sets a matrix variable
		/// </summary>
		/// <param name="name">Name</param>
		/// <param name="data">Data</param>
		public bool SetMatrix(string name, double [,] data)
		{
			if(!Active) return false;
			try 
			{
				argsCall[0] = name;
				argsCall[1] = workspace;
				argsCall[2] = data;
				argsCall[3] = MEmptyW;				
				LateBinding.LateCall(matObject, null, "PutFullMatrix", argsCall, null, null);								
				// a little adjustment because of problems				
				return Evaluate(String.Format("{0} = real({0});", name));
			}
			catch(Exception )
			{
				return false;
			}			
		}

		/// <summary>
		/// Closes the Connection to MATLAB
		/// </summary>
		public void Close()
		{
			if(!Active) return;
			matObject = null;
		}

		/// <summary>
		/// Tells if the connection is Active
		/// </summary>
		public bool Active
		{
			get { return matObject != null; }
		}


		/// <summary>
		/// The Current WorkSpace
		/// </summary>
		public string WorkSpace
		{
			get { return workspace; }
			set { workspace = value; }
		}


		/// <summary>
		/// The COM IDispatch Object
		/// </summary>
		object matObject;
		string workspace = "base";		
		string supportVariable = "xxxx_yyyy_cs_support";		
		static double [] MEmpty = new double[1];
		static double [] MEmptyW = new double[0];

		double [,] MSize = new double[1,2];
		object [] argsCall = new object[4];
		bool   [] argsCallBack = new bool[4] { false, false, true, false };
		object [] argsGet = new object[1];		
	}
}
