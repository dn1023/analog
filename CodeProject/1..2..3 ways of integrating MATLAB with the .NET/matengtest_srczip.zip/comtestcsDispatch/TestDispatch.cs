// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: direct COM interface to MATLAB using Visual Basic serivces
using System;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic;

namespace comtestcsDispatch
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{			
			object matobject;
			object [] args = new object[4];
			bool   [] argsBack = new bool[4] { false, false, true, false } ;
			string workspace = "base";
			string targetVar = "A";
			string supportVar = "xxx_cs";

			// 1) createobject
			matobject = Interaction.CreateObject("Matlab.Application","");
			if(matobject == null)
			{
				Console.WriteLine("Cannot Create The Matlab Object");
				return;
			}
			// 2) execute
			object rObject = LateBinding.LateGet(matobject,null, "Execute", new object [] { String.Format("{0} = [1 2 3] ",targetVar) }, null, null);
			Console.WriteLine("Executed!");
			string r = StringType.FromObject(rObject);
			Console.WriteLine("Result: {0}", r);
			
			// 3) get the array
			
			// a. First get the size of the array using an hack
			//    store the size into a known sized array
			LateBinding.LateGet(matobject,null, "Execute", new object [] { String.Format("{1} = size({0});", targetVar, supportVar) }, null, null);			
			double [,] MReal;
			double [,] MSize = new double[1,2];			
			double [] MEmpty = new double[1];
			
			args[0] = supportVar;
			args[1] = workspace;
			args[2] = MSize;
			args[3] = MEmpty;
			LateBinding.LateCall(matobject, null, "GetFullMatrix", args, null,
				argsBack);
			MSize = (double[,])args[2];
			Console.WriteLine("Executed! GetFullMatrix");
			Console.WriteLine("Sizes: {0} {1}", MSize[0,0],MSize[0,1]);			
			
			// b. then get the data
			if(MSize[0,0] != 0 && MSize[0,1] != 0)
			{
				MReal = new double[(int)(MSize[0,0]),(int)(MSize[0,1])];
				args[0] = targetVar;
				args[1] = workspace;
				args[2] = MReal;
				args[3] = MEmpty;
				LateBinding.LateCall(matobject, null, "GetFullMatrix", args, null,
					argsBack);
				MReal  = (double[,])args[2];
				Console.WriteLine("A = {0} {1} {2}", MReal[0,0],MReal[0,1], MReal[0,2]);			

				// 4) put, be carefule MImag should be empty 
				// so use this hack
				// create an empty matrix
				rObject = LateBinding.LateGet(matobject,null, "Execute", new object [] { String.Format("{0} = [];",supportVar) }, null, null);				
				args[0] = supportVar;
				args[1] = workspace;
				args[2] = new double[0,0];
				args[3] = MEmpty;
				LateBinding.LateCall(matobject, null, "GetFullMatrix", args, null,
					argsBack);
				// args[2] contain an empty array
				object EmptyArray = args[2];

				MReal[0,0] = 12666;
				args[0] = targetVar;
				args[1] = workspace;
				args[2] = MReal;
				args[3] = EmptyArray;
				LateBinding.LateCall(matobject, null, "PutFullMatrix", args, null, null);

				// Read Again using Execute to test if empty matrix
				rObject = LateBinding.LateGet(matobject,null, "Execute", new object [] { String.Format("isreal({0})",targetVar) }, null, null);				
				Console.WriteLine("IsReal(A)? {0}", StringType.FromObject(rObject));
				rObject = LateBinding.LateGet(matobject,null, "Execute", new object [] { String.Format("imag({0})",targetVar) }, null, null);				
				Console.WriteLine("IMAG(A) = {0}", StringType.FromObject(rObject));

			}
			

		}
	}
}
