// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: common interface to the three solutions, used by ThreeTest
using System;

namespace MATLibrary
{
	/// <summary>
	/// interface for MATLAB access
	/// this is the Maximum Common denominator between the different possibilities
	/// It's just a Demo, and in a real application you should choose one of the
	/// three solutions
	/// 
	/// Specifically the MATLAB Engine solution let use ....
	/// </summary>
	public interface MATAccess
	{
		/// <summary>
		/// Evaluates an expression and returns true on completion		
		/// </summary>
		/// <param name="expression"></param>
		/// <returns></returns>
		bool Evaluate(string expression);

		/// <summary>
		/// Say if the MATLAB window is visible
		/// </summary>
		/// <returns></returns>
		bool IsVisible();

		/// <summary>
		/// Fixes the MATLAB windows visibility
		/// </summary>
		/// <param name="b"></param>
		void SetVisible(bool b);
		
		/// <summary>
		/// Gets a matrix variable 
		/// </summary>
		/// <param name="name">name of the matrix</param>
		/// <param name="data">the matrix, preallocated or not</param>
		/// <returns></returns>
		bool GetMatrix(string name, ref double [,] data);

		/// <summary>
		/// Sets a matrix variable
		/// </summary>
		/// <param name="name">Name</param>
		/// <param name="data">Data</param>
		bool SetMatrix(string name, double [,] data);

		/// <summary>
		/// Closes the Connection to MATLAB
		/// </summary>
		void Close();
	}
}
