		/// <summary>
		/// EXCEL TEST (remember! launch excel!)
		/// 1) open a file
		/// 2) 
		/// </summary>
		static void MainE()
		{
			DDEClient d = new DDEClient();
			if(d == null)
			{
				Console.WriteLine("Cannot create the Client Object");
				return;
			}
			DDEChannel c = d.OpenChannel("excel", "system");
			if(c == null)
			{
				Console.WriteLine("Cannot Open the Channel system");
				return;
			}
			
			if(!c.Execute("[open(\"c:\\documenti\\conti.xls\")]", ""))
			{
				Console.WriteLine("Cannot Execute ...");
			}
			c.Disconnect();
			c = d.OpenChannel("excel", "conti.xls");
			if(c != null)
			{
				string r;
				c.Request("r1c1:r20c1", out r);
				Console.WriteLine(r);
				c.Poke("r2c1:r2c2", "1\t2\r\n");
			}
			else
				Console.WriteLine("Cannot Open the Channel conti");
			d.Close();
		}
