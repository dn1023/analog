// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: Test of the DDE based MATLAB Interface
using System;
using DDEMATLib;
using DDELibrary;

namespace DDEMAT
{
	/// <summary>
	/// Test class form MATLAB DDE Interface
	/// </summary>
	class Test
	{

		/// <summary>
		/// MATLAB testing low level
		/// </summary>
		static void MainM(string[] args)
		{
			DDEClient d = new DDEClient();
			//d.Test();
			
			DDEChannel c = d.OpenChannel("MATLAB", "Engine");
			if(c != null)
			{
				string r;
				if(c.Execute("A = [ 1 2 ]", "EngEvalString"))
					Console.WriteLine("Execution Done");
				if(c.Request("EngStringResult", out r)) 
				{
					Console.WriteLine("Requested Result Done\n{0}", r);
				}
				else
					Console.WriteLine("Requested Result not Done");

				// set a matrix value and then read 
				if(c.Request("A", out r))
				{
					Console.WriteLine("Requested A\n{0}", r);
				}
				
				// "1\t2\t3\r\n2\t3\t4\r\n"
				if(c.Poke("A", "1\r\n"))
				{
					Console.WriteLine("Poked A");
				}

				if(c.Request("A", out r))
				{
					Console.WriteLine("Requested A\n{0}", r);
				}
				c.Disconnect();
			}
			d.Close();
		}

		/// <summary>
		/// MATLAB testing at higher level
		/// </summary>
		static void Main(string [] args)
		{
			DDEMatlab m;
			double [,] mat = null;

			if(args.Length != 0)
			{
				MainM(args);
				return;
			}

			m = new DDEMatlab(false, false);
			
			m.Evaluate("A = [ 1 2 3; 4 5 7];");			
			Console.WriteLine("Assigned a 2x3 matrix to A");
			
			Console.WriteLine("A is ...");
			m.GetMatrix("A", ref mat);
			PrintMatrix(mat);
			
			Console.WriteLine("Setting an element and storing into Q:");
			mat[1,1] = 1000.0;
			m.PutMatrix("Q", mat);
			
			Console.WriteLine("Q is ...");
			m.GetMatrix("Q", ref mat);
			PrintMatrix(mat);

			Console.WriteLine("A is ...");
			m.GetMatrix("A", ref mat);
			PrintMatrix(mat);

			m.Close();
			m = new DDEMatlab(true, true);
			int N = 200;
			m.Evaluate("A = zeros(200,200);");
			m.Evaluate("A(200,200) = 123;");
			if(m.GetMatrix("A", ref mat))
			{
				Console.WriteLine("Matrix A {0} {1} {2}", mat.GetLength(0), mat.GetLength(1), mat[N-1,N-1]);
				mat[N-1,N-1] = 321;
				if(m.PutMatrix("A", mat))
				{					
					Console.WriteLine("Get result of put {0}", m.EvaluateAsString("A(200,200)"));
					if(m.GetMatrix("A", ref mat))
						Console.WriteLine("Matrix A reloaded {0} {1} {2}", mat.GetLength(0), mat.GetLength(1), mat[N-1,N-1]);
				}
			}
		}

		static void PrintMatrix(double [,] m)
		{
			if(m == null) return;
			int n1 = m.GetLength(0);
			int n2 = m.GetLength(1);
			for(int i = 0; i < n1; i++)
			{
				for(int j = 0; j < n2; j++)
				{
					Console.Write(m[i,j].ToString() + " ");
				}
				Console.WriteLine("");
			}
		}
	}
}
