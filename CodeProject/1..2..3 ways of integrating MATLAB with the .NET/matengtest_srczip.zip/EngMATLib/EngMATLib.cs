// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: MATLAB Engine API interface
using System;
using System.Runtime.InteropServices;
using MATLibrary;

namespace EngMATLib
{
	/// <summary>
	/// A P/Invoke interface class for the three groups of MATLAB APIs
	/// - libmx
	/// - libmat
	/// - libeng
	/// </summary>
	public class MATInvoke
	{
		#region Engine Functions
		[DllImport("libeng.dll")]
		public static extern IntPtr engOpen(string startcmd);			
		
		[DllImport("libeng.dll")]
		public static extern IntPtr engClose(IntPtr e);			
		
		[DllImport("libeng.dll")]
		public static extern int engEvalString(IntPtr e, string cmd);			

		[DllImport("libeng.dll")]
		public static extern void engSetVisible(IntPtr e, bool q);

		[DllImport("libeng.dll")]
		public static extern bool engIsVisible(IntPtr e);

		// OBSOLETED from 6.5
		[DllImport("libeng.dll")]
		public static extern int engPutArray(IntPtr e, IntPtr array);			

		// REQUIRES 6.5+
		[DllImport("libeng.dll")]
		public static extern int engPutVariable(IntPtr e, string name, IntPtr array);			

		// REQUIRES 6.5+
		[DllImport("libeng.dll")]
		public static extern IntPtr engGetVariable(IntPtr e, string name);			

		// OBSOLETED from 6.5
		[DllImport("libeng.dll")]
		public static extern IntPtr engGetArray(IntPtr e, string name);			
		#endregion

		#region MX Functions
		// MATRIX FUNCTIONS (libmx.dll)
		public enum mxComplexity { mxREAL, mxCOMPLEX }
		public enum mxClassID 
		{ 
			UNKNOWN,
			CELL,
			STRUCT,
			OBJECT,
			CHAR,
			SPARSE,
			DOUBLE,
			SINGLE,
			INT8,
			UINT8,
			INT16,
			UINT16,
			INT32,
			UINT32,
			INT64,		/* place holder - future enhancements */
			UINT64,		/* place holder - future enhancements */
			FUNCTION,
			OPAQUE		
		}

		// Creates a Matrix with the specified dimensions
		[DllImport("libmx.dll")]
		public static extern IntPtr mxCreateDoubleMatrix(int n, int m, mxComplexity c);

		// Destroy a Matrix
		[DllImport("libmx.dll")]
		public static extern int mxDestroyArray(IntPtr pa);

		// Sets the name of a Matrix
		[DllImport("libmx.dll")]
		public static extern int mxSetName(IntPtr pa, string name);

		// Gets the name of a Matrix
		[DllImport("libmx.dll")]
		public static extern string mxGetName(IntPtr pa);

		// Get the raw pointer to the matrix data as a double *
		[DllImport("libmx.dll")]
		public static extern IntPtr mxGetPr(IntPtr pa);

		// Gets the raw pointer to the matrix data as a void *
		[DllImport("libmx.dll")]
		public static extern IntPtr mxGetData(IntPtr pa);

		// Gets the number of columns
		[DllImport("libmx.dll")]
		public static extern int mxGetN(IntPtr pa);

		// Gets the number of rows
		[DllImport("libmx.dll")]
		public static extern int mxGetM(IntPtr pa);

		// Gets The type of the matrix data
		[DllImport("libmx.dll")]
		public static extern mxClassID mxGetClassID(IntPtr pa);

		[DllImport("libmx.dll")]
		public static extern bool mxIsEmpty(IntPtr a);	
		#endregion

		#region MAT Functions
		[DllImport("libmat.dll")]
		internal static extern int matClose(IntPtr mat);

		[DllImport("libmat.dll")]
		internal static extern IntPtr matOpen(string filename, string mode);

		[DllImport("libmat.dll")]
		internal static extern int matPutArray(IntPtr mat, IntPtr mtx);

		// R13 only
		//[DllImport("libmat.dll")]
		//internal static extern int matPutVariable(IntPtr mat, IntPtr mtx);

		[DllImport("libmat.dll")]
		internal static extern IntPtr matGetArray(IntPtr mat, string name);

		[DllImport("libmat.dll")]
		internal static extern IntPtr matGetArrayHeader(IntPtr mat, string name);

		[DllImport("libmat.dll")]
		internal static extern IntPtr matGetNextArrayHeader(IntPtr mat);

		[DllImport("libmat.dll")]
		internal static extern IntPtr matGetNextArray(IntPtr mat, IntPtr mtx);

		[DllImport("libmat.dll")]
		internal static extern int matDeleteArray(IntPtr mat, string name);

		#endregion

	}

	/// <summary>
	/// A Class to Interface MATLAB with C# using MATLAB Engine API
	/// Of the three methods (COM,DDE,MAT) this is the faster and better one
	/// although it uses unsafe methods to gain direct memory access
	/// </summary>
	public class EngMATAccess: MATAccess, IDisposable
	{
		/// <summary>
		/// Creates the connection
		/// </summary>
		public EngMATAccess()
		{
			engine = MATInvoke.engOpen(null);
		}

		protected virtual void Dispose(bool disp)
		{
			if(Active)
			{
				MATInvoke.engClose(engine);
				engine = IntPtr.Zero;
			}
		}

		/// <summary>
		/// IDisposable implementation
		/// </summary>
		public void Dispose()
		{
			Dispose(true);	
			GC.SuppressFinalize(this);
		}

		~EngMATAccess()
		{
			Dispose(false);
		}

		/// <summary>
		/// Tells if it's active
		/// </summary>
		public bool Active
		{
			get { return engine != IntPtr.Zero; }
		}

		/// <summary>
		/// Evaluates an expression and returns true on completion		
		/// </summary>
		/// <param name="expression"></param>
		/// <returns></returns>
		public bool Evaluate(string expression)
		{
			return MATInvoke.engEvalString(engine, expression) == 0;
		}

		/// <summary>
		/// Say if the MATLAB window is visible
		/// </summary>
		/// <returns></returns>
		public bool IsVisible()
		{
			return MATInvoke.engIsVisible(engine);
		}

		/// <summary>
		/// Fixes the MATLAB windows visibility
		/// </summary>
		/// <param name="b"></param>
		public void SetVisible(bool b)
		{
			MATInvoke.engSetVisible(engine, b);
		}
		
		/// <summary>
		/// Gets a matrix variable 
		/// </summary>
		/// <param name="name">name of the matrix</param>
		/// <param name="data">the matrix, preallocated or not</param>
		/// <returns></returns>
		public bool GetMatrix(string name, ref double [,] data)
		{
			IntPtr aa = MATInvoke.engGetArray(engine, name);
			if(aa == IntPtr.Zero) 
				return false;
			else
			{
				bool r = MxArrayToMatrix(aa, ref data);
				MATInvoke.mxDestroyArray(aa);
				return r;	
			}
		}

		/// <summary>
		/// Sets a matrix variable
		/// </summary>
		/// <param name="name">Name</param>
		/// <param name="data">Data</param>
		public bool SetMatrix(string name, double [,] data)
		{
			if(data == null || !Active) return false;

			IntPtr mta = MatrixToMxArray(data);
			if(mta == IntPtr.Zero)
				return false;
			MATInvoke.mxSetName(mta, name);
			bool b = MATInvoke.engPutArray(engine, mta) == 0;			
			MATInvoke.mxDestroyArray(mta);
			return b;
		}

		/// <summary>
		/// Closes the Connection to MATLAB
		/// </summary>
		public void Close()
		{
			if(Active) 
				Dispose();
		}

		internal static unsafe IntPtr MatrixToMxArray(double[,] fromArray)
		{
			int rows = fromArray.GetLength(0);
			int cols = fromArray.GetLength(1);
			IntPtr mta = MATInvoke.mxCreateDoubleMatrix(rows, cols, MATInvoke.mxComplexity.mxREAL);
			if(mta != IntPtr.Zero)
			{
				double * p = (double*)MATInvoke.mxGetPr(mta).ToPointer();
			
				// MATLAB stores data by column
				for(int j = 0; j < cols; j++)
					for(int i = 0; i < rows; i++)
						*p++ = fromArray[i,j];			
			}
			return mta;
		}

		internal static IntPtr MatrixToMxArray(double[] fromArray, int cols)
		{
			int rows = fromArray.Length / cols;
			IntPtr mta = MATInvoke.mxCreateDoubleMatrix(rows, cols, MATInvoke.mxComplexity.mxREAL);
			if(mta != IntPtr.Zero)
			{
				Marshal.Copy(fromArray, 0, mta, fromArray.Length);		
			}
			return mta;		
		}

		internal static unsafe bool MxArrayToMatrix(IntPtr fromArray, ref double[,] toArray)
		{
			int rows = MATInvoke.mxGetM(fromArray);
			int cols = MATInvoke.mxGetN(fromArray);
			
			MATInvoke.mxClassID type = MATInvoke.mxGetClassID(fromArray);

			// Type Check
			if(type == MATInvoke.mxClassID.DOUBLE)				
			{
				// Size Check
				if(toArray == null || toArray.GetLength(0) != rows || toArray.GetLength(1) != cols)
					toArray = new double[rows, cols];

				// Copy 
				double * p = (double*)MATInvoke.mxGetData(fromArray).ToPointer();
			
				// MATLAB stores data by column			
				for(int j = 0; j < cols; j++)
					for(int i = 0; i < rows; i++)
						toArray[i,j] = *p++;
				return true;
			}		
			else
				return false;
		}

		internal static bool MxArrayToMatrix(IntPtr fromArray, ref double[] toArray, out int cols)
		{
			int rows = MATInvoke.mxGetM(fromArray);
			cols = MATInvoke.mxGetN(fromArray);
			MATInvoke.mxClassID type = MATInvoke.mxGetClassID(fromArray);

			// Type Check
			if(type == MATInvoke.mxClassID.DOUBLE)				
			{
				if(toArray == null || toArray.Length < rows*cols)
					toArray = new double[rows*cols];

				Marshal.Copy(MATInvoke.mxGetData(fromArray), toArray, 0, rows*cols);
				return true;
			}		
			else
				return false;		
		}

		/// <summary>
		/// The MATLAB Engine Handle
		/// </summary>
		IntPtr engine;
	}

	/// <summary>
	/// A Structure that describes a Matrix
	/// </summary>
	public class MatrixDescription
	{
		/// <summary>
		/// Create it from an mxArray
		/// </summary>
		/// <param name="ma"></param>
		internal MatrixDescription(IntPtr ma)
		{
			if(ma == IntPtr.Zero) 
				return;
			Rows = MATInvoke.mxGetM(ma);
			Cols = MATInvoke.mxGetN(ma);			
			Type = MATInvoke.mxGetClassID(ma);			
			Name = MATInvoke.mxGetName(ma);
		}

		/// <summary>
		/// The string representation of the data elements
		/// </summary>
		public string TypeName
		{
			get { return Enum.GetName(typeof(MATInvoke.mxClassID),Type); }
		}

		/// <summary>
		/// A string representation of the description
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return String.Format("Matrix {0}: {1}x{2} {3}", Name, Rows, Cols, TypeName);
		}

		/// <summary>
		/// The data type of the Matrix 
		/// </summary>
		public MATInvoke.mxClassID Type;
		/// <summary>
		/// The name of the variable
		/// </summary>
		public string			   Name;
		/// <summary>
		/// The number of rows
		/// </summary>
		public int				   Rows;
		/// <summary>
		/// The number of columns
		/// </summary>
		public int				   Cols;
	}

}
