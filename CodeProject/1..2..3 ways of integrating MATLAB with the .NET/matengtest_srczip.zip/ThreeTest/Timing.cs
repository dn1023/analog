// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: timing support file
using System;
using System.Runtime.InteropServices;

namespace ThreeTest
{
	/// <summary>
	/// Summary description for Timing.
	/// </summary>
	public class Timing
	{
		[ DllImport( "Kernel32.dll" )]
		static extern int GetTickCount( );

		public static void Go()
		{
			start = GetTickCount();
		}

		public static void Stop(string n)
		{
			int stop = GetTickCount();
			Console.Out.WriteLine(n + ": " + (stop-start) + "ms");
		}
	
		static int start;		
	}
}
