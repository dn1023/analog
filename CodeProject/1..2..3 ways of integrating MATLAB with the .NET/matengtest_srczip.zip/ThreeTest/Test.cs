// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: global test of the three solutions: COM DDE API
using System;
using MATLibrary;
using EngMATLib;
using DDEMATLib;
using COMMATLib;


namespace ThreeTest
{
	/// <summary>
	/// A Testing Class for the three different MATLAB access types:
	/// - DDE
	/// - COM
	/// - Engine
	/// 
	/// Notice: DEE requires that MATLAB should be running!
	/// </summary>
	public class Test
	{
		static bool bigtest = true;
		static int NRBIG = 200;
		static int NCBIG = 200;

		/// <summary>
		/// Test a MATLAB interface
		/// </summary>
		/// <param name="ma">MATLAB accessor</param>
		/// <param name="t">name of access (to make unique matrix)</param>
		public static void TestIt(MATAccess ma, string t)
		{
			try
			{	
				bool r;
				double [,] a = null;
				double [,] aa = new double[7,8];
				string matname = "AX"+t;
				string matnameW = "AXS"+t;

				Timing.Go();
				r = ma.Evaluate(matname + " = [ 1 2 3; 4 5 6];");				
				Timing.Stop("Evaluateted " + r);

				Timing.Go();
				r = ma.GetMatrix(matname, ref a);
				Timing.Stop("Got Matrix a " + r);
				if(r)
				{
					Console.WriteLine("Value [2,1] = " + a[1,0]);	
				}

				aa[3,4] = 666;
				Timing.Go();
				r = ma.SetMatrix(matnameW, aa);
				Timing.Stop("Write Matrix " + r);
				if(r)
				{
					Timing.Go();
					r = ma.GetMatrix(matnameW, ref a);
					Timing.Stop("Read Matrix again " + r);
					if(r)
					{
						Console.WriteLine("Orig {0} ?==? New {1}", 
							aa[3,4], a[3,4]);
					}
				}

				if(bigtest)
				{
					double [,] bigmatrix = new double[NRBIG,NCBIG];
					int q = 0;
					for(int i = 0; i < NRBIG; i++)
						for(int j = 0; j < NCBIG; j++)
							bigmatrix[i,j] = q++;
					Timing.Go();
					r = ma.SetMatrix(matname, bigmatrix);
					Timing.Stop(String.Format("Written big matrix {0}x{1} {2}", NRBIG, NCBIG,r));
					Timing.Go();
					r = ma.GetMatrix(matname, ref a);
					Timing.Stop(String.Format("Read big matrix {0}x{1} {2}", NRBIG, NCBIG, r));
					if(r)
					{
						Console.WriteLine("Orig {0} ?==? New {1}",
							bigmatrix[NRBIG-20,NCBIG-10], a[NRBIG-20,NCBIG-10]);
					}
				}

			}
			catch(Exception e)
			{
				Console.WriteLine("Got exception " + e.ToString());
			}
		}

		public static void Main(string []args)
		{
			
			if(args.Length == 0 || args[0] == "dde")
			{
				DDEMatlab ddem = new DDEMatlab(false, false);
				Console.WriteLine("Testing DDE...");
				TestIt(ddem, "dde");
				ddem.Close();
				Console.WriteLine("\n");
			}

			if(args.Length == 0 || args[0] == "ddexl")
			{
				DDEMatlab ddem = new DDEMatlab(true, true);
				Console.WriteLine("Testing DDE with POKE & XLTABLE ...");
				TestIt(ddem, "ddepx");
				ddem.Close();
				Console.WriteLine("\n");
			}

			if(args.Length == 0 || args[0] == "com")
			{
				COMMATAccess comm = new COMMATAccess();
				Console.WriteLine("Testing COM...");
				TestIt(comm, "com");
				TestIt(comm, "com");
				comm.Close();
				Console.WriteLine("\n");
			}

			if(args.Length == 0 || args[0] == "eng")
			{
				EngMATAccess engm =new EngMATAccess();
				Console.WriteLine("Testing MATLAB Engine ...");
				TestIt(engm, "eng");
				engm.Close();
				Console.WriteLine("\n");
			}
		}
	}
}
