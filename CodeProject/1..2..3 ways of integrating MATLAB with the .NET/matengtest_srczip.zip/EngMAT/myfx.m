function y = myfx(m)
	y = magic(m);