// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: direct test of Engine API
using System;
using System.IO;
using System.Runtime.InteropServices;
using EngMATLib;


namespace EngMAT
{
	/// <summary>
	/// Test of direct Access through MATLAB Engine API
	/// </summary>
	class Class1
	{

		[DllImport("libmex.dll", CharSet = CharSet.Ansi)]
		public static extern unsafe int mexCallMATLAB(int n, IntPtr s, int nr, IntPtr d, string command);
		
		//R13[DllImport("libeng.dll")]
		//public static extern int engPutVariable(IntPtr e, string name, IntPtr array);			

		public static unsafe bool CallMATLAB(IntPtr [] inputs, IntPtr[] outputs, string command)
		{
			int n1 = inputs.Length;
			int n2 = outputs.Length;
			fixed(IntPtr* p1 = inputs, p2 = outputs)
			{
				return mexCallMATLAB(n1, *p1, n2, *p2, command) == 0;
			}
		}

		/// <summary>
		/// Low level MATLAB Engine Test, use EngMATLib to work in higher level
		/// </summary>
		[STAThread]
		static unsafe void Main(string[] args)
		{
			IntPtr engine;
			
			engine = MATInvoke.engOpen(null);
			MATInvoke.engEvalString(engine, "A = 10;");
			MATInvoke.engEvalString(engine, "addpath "  + Directory.GetCurrentDirectory());
			IntPtr q = MATInvoke.engGetArray(engine, "A");
			Console.WriteLine(" A is named " + MATInvoke.mxGetName(q));

			MATInvoke.mxSetName(q, "Q");
			MATInvoke.engPutArray(engine, q);

			q = MATInvoke.mxCreateDoubleMatrix(20,20, MATInvoke.mxComplexity.mxREAL);
			MATInvoke.mxSetName(q, "QQ");

			IntPtr qp = MATInvoke.mxGetPr(q);
			if(qp.ToInt32() != 0)
			{
				// now we have a double * not managed!
				double * pp = (double*)qp.ToPointer();
				pp[0] = 100;
			}
			MATInvoke.engPutArray(engine, q);

			MATInvoke.engEvalString(engine, "Q = myfx(3);");
			q = MATInvoke.engGetArray(engine, "A");
			Console.WriteLine(" A is named " + MATInvoke.mxGetName(q));

//			// finally try with the execute(it doesn't work but it's not a problem)
//			IntPtr r = mxCreateDoubleMatrix(1,2, mxComplexity.mxREAL);
//			IntPtr [] ins = { qp };
//			IntPtr [] outs = {r };
//			CallMATLAB(ins, outs, "zeros");

			

			//engClose(engine);
		}
	}
}
