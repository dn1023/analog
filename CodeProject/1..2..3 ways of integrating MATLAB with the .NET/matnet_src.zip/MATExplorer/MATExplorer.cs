// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: GUI based .MAT file Explorer (read only access)
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using EngMATLib;

namespace MATExplorer
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MATExplorer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.TextBox edFilename;
		private System.Windows.Forms.Button btnRefresh;
		private System.Windows.Forms.ListView mtxView;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MATExplorer()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public MATExplorer(string s) : this()
		{
			BrowseNewFile(s);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mtxView = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.edFilename = new System.Windows.Forms.TextBox();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// mtxView
			// 
			this.mtxView.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.mtxView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					  this.columnHeader1,
																					  this.columnHeader2,
																					  this.columnHeader3,
																					  this.columnHeader4});
			this.mtxView.FullRowSelect = true;
			this.mtxView.Location = new System.Drawing.Point(8, 40);
			this.mtxView.Name = "mtxView";
			this.mtxView.Size = new System.Drawing.Size(560, 224);
			this.mtxView.TabIndex = 1;
			this.mtxView.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Name";
			this.columnHeader1.Width = 200;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Type";
			this.columnHeader2.Width = 120;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Rows";
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Columns";
			// 
			// btnBrowse
			// 
			this.btnBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnBrowse.Location = new System.Drawing.Point(248, 272);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(104, 24);
			this.btnBrowse.TabIndex = 2;
			this.btnBrowse.Text = "&Browse";
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// button1
			// 
			this.button1.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.button1.Location = new System.Drawing.Point(464, 272);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(104, 24);
			this.button1.TabIndex = 3;
			this.button1.Text = "&Close";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// edFilename
			// 
			this.edFilename.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.edFilename.Location = new System.Drawing.Point(8, 8);
			this.edFilename.Name = "edFilename";
			this.edFilename.ReadOnly = true;
			this.edFilename.Size = new System.Drawing.Size(560, 20);
			this.edFilename.TabIndex = 4;
			this.edFilename.Text = "";
			// 
			// btnRefresh
			// 
			this.btnRefresh.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnRefresh.Location = new System.Drawing.Point(360, 272);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(96, 24);
			this.btnRefresh.TabIndex = 5;
			this.btnRefresh.Text = "Refresh";
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// MATExplorer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 301);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnRefresh,
																		  this.edFilename,
																		  this.button1,
																		  this.btnBrowse,
																		  this.mtxView});
			this.Name = "MATExplorer";
			this.Text = "MAT File Explorer";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string [] args) 
		{
			if(args.Length == 0)
				Application.Run(new MATExplorer());
			else
			{
				foreach(string s in args)
				{
					Application.Run(new MATExplorer(s));
				}
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void btnBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog fd = new OpenFileDialog();
			fd.Filter = "MAT Files (*.mat)|*.mat|All Files (*.*)|*.*";
			fd.FilterIndex = 1;
			fd.RestoreDirectory = true;
			if(fd.ShowDialog() == DialogResult.OK)
			{
				BrowseNewFile(fd.FileName);
			}
		}

		public void BrowseNewFile(string filename)
		{
			mat.Close();
			mat.Open(filename, FileAccess.Read);
			edFilename.Text = filename;
			RefreshView();
		}

		public void RefreshView()
		{
			mtxView.Items.Clear();
			if(!mat.IsOpened)
				return;

			NamedMatrixCollection mtx = mat.Variables;
			foreach(string s in mtx.Keys)
			{
				MatrixDescription md = mtx[s];
				ListViewItem lvi = new ListViewItem(new
					string [] { md.Name, md.TypeName, md.Rows.ToString(), md.Cols.ToString()});
				mtxView.Items.Add(lvi);
			}								
		}

		MATFile mat = new MATFile();

		private void btnRefresh_Click(object sender, System.EventArgs e)
		{
			RefreshView();
		}
	}
}
