using System;
using EngMATLib;
using System.Runtime.InteropServices;

namespace TestMATEng
{
	class MyDLL
	{
		/// <summary>
		/// 
		/// </summary>
		[DllImport("AAX.dll")]
		static extern IntPtr mlfAA(IntPtr a);
	
		/// <summary>
		/// External interface to my MATLAB function
		/// </summary>
		/// <param name="m"></param>
		/// <returns></returns>
		static public Matrix mlfAA(Matrix m)
		{
			return new Matrix(mlfAA((IntPtr)m));
		}
	}
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Test
	{


		[DllImport("AAX.dll")]
		public static extern void AAXInitialize();

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			using (EngMATAccess mat = new EngMATAccess())
			{
						
				double [,] a = new double [20,20];
				a[0,0] = 10;
				a[0,1] = 20;
				a[1,0] = 30;
				int cols;

				// initializes the custom library
				AAXInitialize();

				Matrix rmax = MyDLL.mlfAA(new Matrix(a, false));
				Console.WriteLine("Result data is {0}x{1}", rmax.Rows, rmax.Cols);
				double [,] r = rmax.AsMatrix();
				Console.WriteLine("\tFirst two result values are {0} {1}", r[0,0],r[0,1]);

				EngMATAccess.MxArrayToMatrix(MyDLL.mlfAA(new Matrix(r)), ref r);
				Console.WriteLine("\tResults again is {0} {1}", r[0,0],r[0,1]);
				Console.WriteLine("Press any key to terminate");
				Console.ReadLine();
			}
		}
	}
}
