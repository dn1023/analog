using System;
using EngMATLib;

namespace TestEngMAT
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Test
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Mainas(string[] args)
		{
			using (EngMATAccess mat = new EngMATAccess())
			{
				Console.WriteLine(mat.EvaluateAsString("A = [ 1 2 3; 3 5 6]"));
				double [,] mx = null;

				mat.GetMatrix("A", ref mx);
				Console.WriteLine(mx[0,0]);
				mx[0,0] = 1000;
				mat.SetMatrix("A", mx);
				Console.WriteLine(mat.EvaluateAsString("A"));

				using (MATFile matfile = new MATFile("afile.mat", FileAccess.Update))
				{
					matfile.PutMatrix("Q", mx);
				}
				
				using(MATFile matfile = new MATFile("afile.mat", FileAccess.Read))
				{
					matfile.GetMatrix("Q", ref mx);
					mat.SetMatrix("Q", mx);
					Console.WriteLine(mat.EvaluateAsString("Q"));
				}
			}
		}
	}
}
