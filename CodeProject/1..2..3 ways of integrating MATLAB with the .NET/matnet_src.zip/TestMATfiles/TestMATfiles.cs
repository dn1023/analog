// Matlab Interface Library
// by Emanuele Ruffaldi 2002
// http://www.sssup.it/~pit/
// mailto:pit@sssup.it
//
// Description: test of MAT File API
using System;
using EngMATLib;

namespace TestMATfiles
{
	/// <summary>
	/// Testing of the MAT library
	/// </summary>
	class Test
	{
		static void ListMATFile(string name)
		{
			using (MATFile mat = new MATFile(name, FileAccess.Read))
			  {
				if(!mat.IsOpened)
				{
					Console.WriteLine("Cannot open file {0}", mat.Filename);
					return;
				}

				NamedMatrixCollection mtx = mat.Variables;
				foreach(string s in mtx.Keys)
				{
					Console.WriteLine(mtx[s]);
				}		
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			ListMATFile("demos.mat");
			double[,] myma = null;

			using (MATFile mat = new MATFile("demos.mat", FileAccess.Read))
			{
				
				if(mat.GetMatrix("long", ref myma))
				{
					Console.WriteLine("Got Matrix {0}", myma[0,0]);
				}
			}
			using (MATFile mat = new MATFile("demos2.mat", FileAccess.Write))
			{
				mat.PutMatrix("hello", myma);
			}
			ListMATFile("demos2.mat");
		}
	}
}
