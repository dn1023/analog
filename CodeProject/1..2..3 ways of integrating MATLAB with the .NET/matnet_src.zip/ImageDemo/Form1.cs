using System;
using EngMATLib;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ImageDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pictureBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1(string f)
		{
			filename = f;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(712, 600);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.ClientSize = new System.Drawing.Size(712, 600);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pictureBox1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(String [] args) 
		{
			if(args.Length == 0)
			{
				MessageBox.Show("MATNET Image Demo", "Required as arguments the name of an image file");
			}
			else
				Application.Run(new Form1(args[0]));
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			bit = new Bitmap(filename);
			pictureBox1.Image = bit;
		}

		string filename;
		Bitmap bit;

		public static unsafe Matrix Bitmap2Matrix(Bitmap bit)
		{
			int w = bit.Width;
			int h= bit.Height;
			if(bit.PixelFormat == PixelFormat.Format16bppGrayScale)
			{
				Matrix m = new Matrix(w,h, typeof(byte));
				BitmapData bd = bit.LockBits(new Rectangle(0,0,w,h),ImageLockMode.ReadOnly,bit.PixelFormat);

			{
				byte * p = (byte*)MATInvoke.mxGetData(m).ToPointer();

				// MATLAB stores data by column			
				for(int j = 0; j < w; j++)
				{
					short * pp = (short*)bd.Scan0;
					pp += j;
					for(int i = 0; i < h; i++, pp+= bd.Stride)
						*p++ = (byte)*pp;
				}
			}
				bit.UnlockBits(bd);
				return m;
			}
			else if(bit.PixelFormat == PixelFormat.Format32bppRgb)
			{
				Matrix m = new Matrix(w*3,h,typeof(byte));
				byte * p = (byte*)MATInvoke.mxGetData(m).ToPointer();
				BitmapData bd = bit.LockBits(new Rectangle(0,0,w,h),ImageLockMode.ReadOnly,bit.PixelFormat);

				// MATLAB stores data by column			
				for(int j = 0; j < w; j++)
				{
					byte * pp = (byte*)bd.Scan0;
					pp += j*4;
					for(int k = 0; k < 3; k++, pp++)
					{
						byte * spp = pp;
						for(int i = 0; i < h; i++, spp+= bd.Stride)
							*p++ = *spp;
					}
				}
				bit.UnlockBits(bd);
				return m;
			}
			else if(bit.PixelFormat == PixelFormat.Format24bppRgb)
			{
				Matrix m = new Matrix(h,w,3,typeof(byte));
				byte * p = (byte*)MATInvoke.mxGetData(m).ToPointer();
				BitmapData bd = bit.LockBits(new Rectangle(0,0,w,h),ImageLockMode.ReadOnly,bit.PixelFormat);
				byte * pp = (byte*)bd.Scan0;

				// i*w*3+j*3+c => c*h*w+j*h+i
				for(int i = 0; i < w; i++, pp+=3)
				{
					byte * sp = pp;
					for(int j = 0; j < h; j++, p++, sp += bd.Stride)
					{
						p[0] = sp[2];
						p[h*w] = sp[1];
						p[h*w*2] = sp[0];
					}
				}

				// Matrix Layout is columnwise -> by plane, and then by X
				/*
				 * p = (byte*)MATInvoke.mxGetData(m).ToPointer();
				for(int j = 0; j < w; j++)
				{
					for(int i = 0; i < h; i++)
					{
						// i*w*3+j*3+c => c*h*w+j*h+i
						p[j*h+i] = 255;
						p[h*w+j*h+i] = 0;
						p[h*w*2+j*h+i] = 255;
					}
				}
				*/
				bit.UnlockBits(bd);
				return m;
			}
			else
				return null;
		}

		public unsafe static void  Matrix2Bitmap(Bitmap bit, Matrix m)
		{
			int w = bit.Width;
			int h= bit.Height;
			if(bit.PixelFormat == PixelFormat.Format24bppRgb)
			{
				byte * p = (byte*)MATInvoke.mxGetData(m).ToPointer();
				BitmapData bd = bit.LockBits(new Rectangle(0,0,w,h),ImageLockMode.ReadOnly,bit.PixelFormat);
				byte * pp = (byte*)bd.Scan0;

				// i*w*3+j*3+c => c*h*w+j*h+i
				for(int i = 0; i < w; i++, pp+=3)
				{
					byte * sp = pp;
					for(int j = 0; j < h; j++, p++, sp += bd.Stride)
					{
						sp[2] = p[0];
						sp[1] = p[h*w];
						sp[0] = p[h*w*2];
					}
				}

				// Matrix Layout is columnwise -> by plane, and then by X
				/*
				 * p = (byte*)MATInvoke.mxGetData(m).ToPointer();
				for(int j = 0; j < w; j++)
				{
					for(int i = 0; i < h; i++)
					{
						// i*w*3+j*3+c => c*h*w+j*h+i
						p[j*h+i] = 255;
						p[h*w+j*h+i] = 0;
						p[h*w*2+j*h+i] = 255;
					}
				}
				*/
				bit.UnlockBits(bd);
			}
		}

		private void pictureBox1_Click(object sender, System.EventArgs e)
		{
			// 1) transform the bitmap into a matrix
			// 2) apply matlab transformation or something
			// 3) show the result as bitmap
			using (EngMATAccess mat = new EngMATAccess())
			{
				Matrix mx = Bitmap2Matrix(bit);
				mat.SetMatrix("aa", mx);
				mat.Evaluate("imshow(aa); aa = imnoise(aa);");
				mx = mat.GetMatrix("aa");
				Matrix2Bitmap(bit, mx);
				MessageBox.Show("Hello");
				pictureBox1.Invalidate();
			}			
		}
	}
}
