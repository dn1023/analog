using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using EngMATLib;

namespace TestEngMATGUI
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox textIn;
		private System.Windows.Forms.TextBox textOut;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private EngMATAccess mat;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				mat.Dispose();
				mat = null;
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textIn = new System.Windows.Forms.TextBox();
			this.textOut = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// textIn
			// 
			this.textIn.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textIn.Location = new System.Drawing.Point(0, 24);
			this.textIn.Name = "textIn";
			this.textIn.Size = new System.Drawing.Size(616, 20);
			this.textIn.TabIndex = 0;
			this.textIn.Text = "A = [ 1 2 3]";
			this.textIn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textIn_KeyPress);
			// 
			// textOut
			// 
			this.textOut.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textOut.Location = new System.Drawing.Point(0, 72);
			this.textOut.Multiline = true;
			this.textOut.Name = "textOut";
			this.textOut.ReadOnly = true;
			this.textOut.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textOut.Size = new System.Drawing.Size(616, 192);
			this.textOut.TabIndex = 1;
			this.textOut.Text = "";
			// 
			// label1
			// 
			this.label1.Name = "label1";
			this.label1.TabIndex = 2;
			this.label1.Text = "Input";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 48);
			this.label2.Name = "label2";
			this.label2.TabIndex = 3;
			this.label2.Text = "Output";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(624, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label2,
																		  this.label1,
																		  this.textOut,
																		  this.textIn});
			this.Name = "Form1";
			this.Text = "MATLAB Engine Test";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			mat = new EngMATAccess(4096);
			if(!mat.Active)
			{
				MessageBox.Show("Cannot connect with MATLAB, it should be on the path");
				Application.Exit();
			}			
		}

		private void textIn_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if(e.KeyChar == 13)
			{
				string r = mat.EvaluateAsString(textIn.Text);
				textOut.Text = r.Replace("\x0A", "\x0D\x0A");
			}
		}

	}
}
