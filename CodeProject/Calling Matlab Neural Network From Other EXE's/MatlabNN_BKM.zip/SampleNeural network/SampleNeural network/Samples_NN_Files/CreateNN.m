%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      This M file Creates Sample Nueral NetWork Save The Network               %
%                   Author : Baiju K M                                          %                           
%                   Created On : 08-July-2004                                   %
%                    Email: Baijumax@rediffmail.com                             % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function CreateNN()
P = [1.0 -1.2];     %Inputs 
T = [0.5 1.0];      %Targets

%Create The NetWork using above Params
net = newlind(P,T);

%Save Worksspace to Current Working Folder
save SampleWorkSpace net;
    