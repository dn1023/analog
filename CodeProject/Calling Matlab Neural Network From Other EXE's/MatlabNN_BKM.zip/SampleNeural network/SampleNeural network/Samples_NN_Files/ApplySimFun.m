%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              This M file Apply Sim fuction ,Writes The Result to Log file     %
%                   Author : Baiju K M                                          %                           
%                   Created On : 08-July-2004                                   %
%                    Email: Baijumax@rediffmail.com                             % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ApplySimFun()

%Load The Previously created Network  ,select workspace

load SampleWorkSpace;
%net = SampleWorkSpace.net;
%apply simulate function 
P = [1.0 -1.2];  %inputs
A=sim(net,P);

%Now matrix A Contains Predictive values Write The Values To a Notepad
%Files
RESULT_FILE = fopen('C:\\NNResult.log','w');
fprintf(RESULT_FILE,'\n Results -----> %d   %d \n',A(1),A(2));
fclose(RESULT_FILE);