How To Test The Apllication

i wrote two sample file .m files , foldername Samples_NN_Files

step1 , copy Samples_NN_Files  Folder to c:\
   
       folder contains two .m file ,
       file ,CreateNN.m  ->  creates the network , save the network to c:\Samples_NN_Files
       file , ApplySimFun.m -> loads the network from c:\Samples_NN_Files apply the simulate        function, write the result to a log file C:\NNResult.log"



Step2 , u have to call these file(execute) from .exe(vb,vc,c++)   , I order to do that u have to         invoke matlab as automatomation server.

       for this purpose i wrote wrapper dll called CMatlabEngine.dll.
       so register the dll file (Note:  i am using Matlab 6.5 version so , if u are using anyother versions there may be version conflict) 
       u can find the dll file in vb_dll_matlab folder ( actually it's vb project for creating         matlab wrapper, so go through the code") 

          
           
step 3 ,there's sample programm written vb ,Call_NN_From_VB which call the matlab execute the Network shows the result to testbox


  if any doubts feell free contact me at baijumax@rediffmail.com,baijumax@yahoo.com